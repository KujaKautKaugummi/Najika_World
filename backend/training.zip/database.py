"""
Database Configuration - Najika World
SQLAlchemy setup for Card Games and other systems
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# Database URL (SQLite for development, PostgreSQL for production)
# Use absolute path to backend/najika_game.db to avoid path issues
_backend_dir = os.path.dirname(os.path.abspath(__file__))
_db_path = os.path.join(_backend_dir, "najika_game.db")
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{_db_path}")

# Create engine
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {}
)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create declarative base
Base = declarative_base()


# Dependency for FastAPI
def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Initialize database (create all tables)"""
    # Import all models so they are registered with Base
    from backend.models import user, card_game, dice_monsters, slime_arena

    # Create all tables
    Base.metadata.create_all(bind=engine)
    print("[OK] Database tables created successfully!")
    print(f"[INFO] Tables: {list(Base.metadata.tables.keys())}")


if __name__ == "__main__":
    init_db()
